import { Component, OnInit, AfterViewInit, ComponentFactoryResolver, ViewChild, ViewContainerRef, ViewEncapsulation } from '@angular/core';
import {UserService} from "../../../../.././auth/_services/user.service";
import { ScriptLoaderService } from '../../../../.././_services/script-loader.service';
import { FormsModule , Validator } from '@angular/forms';
import { Router, RouterLink } from "@angular/router";

import { AlertService } from "../../../../../auth/_services/alert.service";
import { AlertComponent } from "../../../../../auth/_directives/alert.component";

import { Helpers } from '../../../../../helpers';

@Component({
  selector: '.m-grid__item.m-grid__item--fluid.m-wrapper',
  templateUrl: "./adduser.component.html",
  encapsulation: ViewEncapsulation.None,
})
export class AdduserComponent implements OnInit {

  model: any = {};
  loading = false;
  mask: any[] = [/[0-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];

  uploadpath = Helpers.logoFavPath;
  uploadfavimg:any={};
  profileboy = true;
  profilegirl = false;

  @ViewChild('alertAddUser', { read: ViewContainerRef }) alertAddUser: ViewContainerRef;

  constructor(private _userService: UserService,
              private _script: ScriptLoaderService,
              private _alertService: AlertService,
              private cfr: ComponentFactoryResolver,
              private _router: Router) {
  }

  ngOnInit() {
    if (localStorage.getItem("currentUser") === null) {
        this._router.navigate(['/login']);
    }
    this.model.status = 1;
    this.model.regtype = 'boy';
    // this._userService.getuserlist()
    //   .subscribe(
    //     data => {
    //       //console.log(data);
    //
    //     },
    //     error => {
    //
    //     });
  }

  ngAfterViewInit() {
      this._script.load('.m-grid__item.m-grid__item--fluid.m-wrapper',
          'assets/app/js/changeusertype.js');

  }

  addUser(form:any){
    Helpers.setLoading(true);
    this.loading = true;
    let tuser = this.model.regtype;
    this.model.images = this.uploadfavimg;
    this.model.adminadd = true;
    if(this.model.regtype == 'boy'){
      this.model.regtype = 'Male';
    }
    if(this.model.regtype == 'Girl'){
      this.model.regtype = 'Female';
    }

    this._userService.create(this.model)
      .subscribe(
        data => {
          //console.log(data);
          Helpers.setLoading(false);
          this.loading = false;
          this.showAlert('alertAddUser');
          if(data.code == 1){
            this._alertService.success("User created successfully");
            form.resetForm();
            this.model.regtype = tuser;
            $(".img-ul-clear").eq( 0 ).trigger('click');
          }
          if(data.code == 2){
            this._alertService.error("Something went wrong");
          }
          if(data.code == 3){
            this._alertService.error("Email already registered, enter different email address");
          }

        },
        error => {
          Helpers.setLoading(false);
          this.loading = false;
          this.showAlert('alertAddUser');
          this._alertService.error("Somthing went wrong");
        });
  }

  showAlert(target) {
      this[target].clear();
      let factory = this.cfr.resolveComponentFactory(AlertComponent);
      let ref = this[target].createComponent(factory);
      ref.changeDetectorRef.detectChanges();
  }

  onUploadFinishedFav(file: any) {
    console.log(file.file);
    this.uploadfavimg[file.file.name] = {};
    var currentimg:any = {};

    currentimg.data = JSON.stringify(file.src);
    currentimg.price = this.model.picprice+'$';
    currentimg.enlock = this.model.islocked;
    //console.log(currentimg);
    this.uploadfavimg[file.file.name] = currentimg;
    console.log(this.uploadfavimg);
  }

  onRemovedFav(file: any) {

    // do some stuff with the removed file.
    delete this.uploadfavimg[file.file.name];
    console.log(this.uploadfavimg);
  }

  onUploadStateChangedFav(state: boolean) {
    console.log(JSON.stringify(state));
  }

  changeType(val){
    if(this.model.regtype == 'boy'){
      this.profileboy = true;
      this.profilegirl = false;
    }
    if(this.model.regtype == 'Girl'){
      this.profileboy = false;
      this.profilegirl = true;
    }
  }

  changelocked(val){
    console.log('locked val:');
    console.log(val);
  }

}
