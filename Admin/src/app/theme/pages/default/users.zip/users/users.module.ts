import { Component, OnInit, ViewEncapsulation, AfterViewInit, NgModule, ComponentFactoryResolver, ViewChild, ViewContainerRef } from '@angular/core';
import { Helpers } from '../../../../helpers';
import { CommonModule } from '@angular/common';
import { LayoutModule } from '../../../layouts/layout.module';
import { DefaultComponent } from '../default.component';
import { FormsModule , Validator } from '@angular/forms';
import { Router, Routes, RouterModule } from "@angular/router";
import { UserlistComponent } from './userlist/userlist.component';
import { AdduserComponent } from './adduser/adduser.component';

import { AlertService } from "../../../../auth/_services/alert.service";
import { AlertComponent } from "../../../../auth/_directives/alert.component";
import { TextMaskModule } from 'angular2-text-mask';
import { ImageUploadModule } from "angular2-image-upload";
import { EdituserComponent } from './edituser/edituser.component';
import { Socket,SocketIoModule } from 'ng-socket-io';

const routes: Routes = [
    {
        "path": "",
        "component": DefaultComponent,
        "children": [
            {
                path: "",
                component: UserlistComponent
            },
            {
              path: 'add',
              component: AdduserComponent
            } ,
            {
              path: 'edit/:id',
              component: EdituserComponent
            }
        ]
    }
];

@NgModule({
imports: [
        CommonModule, RouterModule.forChild(routes), LayoutModule, FormsModule,TextMaskModule, ImageUploadModule.forRoot(),SocketIoModule
    ], exports: [
        RouterModule
    ],
    declarations: [UserlistComponent, AdduserComponent, EdituserComponent]
})

export class UsersComponent {

  constructor() { }

  ngOnInit() {
  }

}
