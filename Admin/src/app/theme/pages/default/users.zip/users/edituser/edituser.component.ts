import { Component, OnInit, AfterViewInit, ComponentFactoryResolver, ViewChild, ViewContainerRef, ViewEncapsulation } from '@angular/core';
import {UserService} from "../../../../.././auth/_services/user.service";
import { ScriptLoaderService } from '../../../../.././_services/script-loader.service';
import { FormsModule , Validator } from '@angular/forms';
import { Router, RouterLink, NavigationEnd } from "@angular/router";

import { AlertService } from "../../../../../auth/_services/alert.service";
import { AlertComponent } from "../../../../../auth/_directives/alert.component";

import { Helpers } from '../../../../../helpers';

@Component({
  selector: '.m-grid__item.m-grid__item--fluid.m-wrapper',
  templateUrl: "./edituser.component.html",
  encapsulation: ViewEncapsulation.None,
})
export class EdituserComponent implements OnInit {

  model: any = {};
  loading = false;
  mask: any[] = [/[0-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];

  uploadpath = Helpers.logoFavPath+'profile';
  uploadfavimg:any={};
  profileboy = true;
  profilegirl = false;
  currentUrl = '';
  userid:any;
  usergirl = false;
  userboy = false;
  currentimages = [];
  newimages = false;

  @ViewChild('alertAddUser', { read: ViewContainerRef }) alertAddUser: ViewContainerRef;

  constructor(private _userService: UserService,
              private _script: ScriptLoaderService,
              private _alertService: AlertService,
              private cfr: ComponentFactoryResolver,
              private _router: Router) {

                _router.events.subscribe((event: any) => {
                  if (event instanceof NavigationEnd ) {
                    this.currentUrl = event.url;
                    //console.log(this.currentUrl);
                    let urldata=this.currentUrl.split("/");
                    //console.log(urldata);
                    let pid=urldata[3];
            				this.userid=pid;
                  }
                });
  }

  ngOnInit() {
    if (localStorage.getItem("currentUser") === null) {
        this._router.navigate(['/login']);
    }


    Helpers.setLoading(true);
    this.loading = true;
    this._userService.getById(this.userid)
      .subscribe(
        data => {
          //console.log(data);
          Helpers.setLoading(false);
          this.loading = false;
          this.showAlert('alertAddUser');
          if(data.error == false){
            this.model = data.sdata;
            if(this.model.gender == 'Female'){
              this.usergirl = true;
              this.model.regtype = 'Girl';
              //let ci = {};
              //this.currentimages.push(this.uploadpath);
              // let allcis = {};
              // for(let img of this.model.images)
              // {
              //   console.log(img);
              //     ci['filename']=img;
              //     ci['url']=this.uploadpath;
              //     this.currentimages.push(ci);
              // }

              //console.log(this.currentimages);
              this.currentimages = this.model.profile_pic;
              let price = this.model.profile_pic[0].price.split('$');
              console.log(price);
              this.model.picprice = parseFloat(price[0]);
              this.model.islocked = this.model.profile_pic[0].lock;
            } else{
              this.userboy = true;
              this.model.regtype = 'boy';
              this.currentimages = this.model.profile_pic;
            }

          }
          else{
            this._alertService.error("Somthing went wrong");
          }


        },
        error => {
          Helpers.setLoading(false);
          this.loading = false;
          this.showAlert('alertAddUser');
          this._alertService.error("Somthing went wrong");
        });

  }

  ngAfterViewInit() {
      this._script.load('.m-grid__item.m-grid__item--fluid.m-wrapper',
          'assets/app/js/changeusertype.js');

  }

  addUser(form:any){
    Helpers.setLoading(true);
    this.loading = true;
    let tuser = this.model.regtype;


    var keys = Object.keys(this.uploadfavimg);
    var len = keys.length;
    //console.log('upimgl:'+len);

    this.model.images = this.uploadfavimg;
    this.model.oldimages = this.currentimages;
    this._userService.update(this.model)
      .subscribe(
        data => {
          //console.log(data);
          Helpers.setLoading(false);
          this.loading = false;
          this.showAlert('alertAddUser');
          if(data.code == 1){
            this._alertService.success("User updated successfully");

            this.model.regtype = tuser;
            $(".img-ul-clear").eq( 0 ).trigger('click');
            //window.location.reload();
            if(data.newimages == true){
              this.currentimages = data.imgsare;
            }
          }
          if(data.code == 2){
            this._alertService.error("Email already registered, enter different email address");
          }
          if(data.code == 3){
            this._alertService.error("Something went wrong");
          }

        },
        error => {
          Helpers.setLoading(false);
          this.loading = false;
          this.showAlert('alertAddUser');
          this._alertService.error("Somthing went wrong");
        });
  }

  showAlert(target) {
      this[target].clear();
      let factory = this.cfr.resolveComponentFactory(AlertComponent);
      let ref = this[target].createComponent(factory);
      ref.changeDetectorRef.detectChanges();
  }

  onUploadFinishedFav(file: any) {
    console.log(file.file);

    this.uploadfavimg[file.file.name] = {};
    var currentimg:any = {};

    currentimg.data = JSON.stringify(file.src);
    currentimg.price = this.model.picprice+'$';
    currentimg.enlock = this.model.islocked;

    this.uploadfavimg[file.file.name] = currentimg;
  }

  onRemovedFav(file: any) {

    // do some stuff with the removed file.
    delete this.uploadfavimg[file.file.name];
    console.log(this.uploadfavimg);
  }

  onUploadStateChangedFav(state: boolean) {
    console.log(JSON.stringify(state));
  }

  changeType(val){
    if(this.model.regtype == 'boy'){
      this.profileboy = true;
      this.profilegirl = false;
    }
    if(this.model.regtype == 'Girl'){
      this.profileboy = false;
      this.profilegirl = true;
    }
  }

  removeimage(val){
    //console.log('index:'+val);
    this.currentimages.splice(val,1);
  }

}
