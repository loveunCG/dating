function changeusertype(type){
  if(type=='boy'){
    $('#girl').hide();
    $('#boy').show();
  }
  if(type=='Girl'){
    $('#girl').show();
    $('#boy').hide();
  }
}
